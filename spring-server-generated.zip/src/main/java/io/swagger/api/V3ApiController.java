package io.swagger.api;

import io.swagger.model.Error;
import io.swagger.model.InventoryItem;
import io.swagger.model.InventorySuccessResponse;
import io.swagger.model.User;
import io.swagger.model.UserSuccessResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import javax.validation.constraints.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2024-05-23T10:15:39.378212833Z[GMT]")
@RestController
public class V3ApiController implements V3Api {

    private static final Logger log = LoggerFactory.getLogger(V3ApiController.class);

    private final ObjectMapper objectMapper;

    private final HttpServletRequest request;

    @org.springframework.beans.factory.annotation.Autowired
    public V3ApiController(ObjectMapper objectMapper, HttpServletRequest request) {
        this.objectMapper = objectMapper;
        this.request = request;
    }

    public ResponseEntity<InventorySuccessResponse> addInventory(@Parameter(in = ParameterIn.DEFAULT, description = "Create a new inventory in the store", required=true, schema=@Schema()) @Valid @RequestBody InventoryItem body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<InventorySuccessResponse>(objectMapper.readValue("{\n  \"inventoryItem\" : {\n    \"quantity\" : 7,\n    \"price\" : 7,\n    \"name\" : \"Apples\",\n    \"id\" : 1\n  },\n  \"serviceRequestId\" : \"unique string\",\n  \"code\" : \"code\",\n  \"serviceFlow\" : \"string\",\n  \"message\" : \"message string\",\n  \"status\" : \"SUCCEEDED\"\n}", InventorySuccessResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<InventorySuccessResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<InventorySuccessResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<UserSuccessResponse> createUser(@Parameter(in = ParameterIn.DEFAULT, description = "Created user object", schema=@Schema()) @Valid @RequestBody User body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<UserSuccessResponse>(objectMapper.readValue("{\n  \"serviceRequestId\" : \"unique string\",\n  \"code\" : \"code\",\n  \"serviceFlow\" : \"string\",\n  \"message\" : \"message string\",\n  \"userid\" : \"unique string\",\n  \"status\" : \"SUCCEEDED\"\n}", UserSuccessResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<UserSuccessResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<UserSuccessResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

}
